"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { api } from "@/lib/api"
import { useAuth } from "@/lib/auth"
import { useToast } from "@/hooks/use-toast"
import { Plus, Copy, Trash2, ExternalLink, BarChart3, Calendar } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

export default function DashboardPage() {
  const { user, token } = useAuth()
  const { toast } = useToast()
  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [createOpen, setCreateOpen] = useState(false)
  const [newLink, setNewLink] = useState({ originalUrl: "", title: "" })

  useEffect(() => {
    if (token) fetchLinks()
  }, [token])

  const fetchLinks = async () => {
    try {
      const response = await api.getLinks(token)
      if (response.success) {
        setLinks(response.data)
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to fetch links", variant: "destructive" })
    }
    setLoading(false)
  }

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await api.createLink(newLink, token)
      if (response.success) {
        toast({ title: "Success!", description: "Link created successfully" })
        setCreateOpen(false)
        setNewLink({ originalUrl: "", title: "" })
        fetchLinks()
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to create link", variant: "destructive" })
    }
  }

  const copyLink = (shortCode: string) => {
    navigator.clipboard.writeText(`http://localhost:3000/r/${shortCode}`)
    toast({ title: "Copied!", description: "Link copied to clipboard" })
  }

  const deleteLink = async (id: string) => {
    try {
      await api.deleteLink(id, token)
      toast({ title: "Deleted", description: "Link deleted successfully" })
      fetchLinks()
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete link", variant: "destructive" })
    }
  }

  if (!user) return <div className="p-8 text-center">Please log in</div>

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Welcome back, {user.name}!</h1>
            <p className="text-gray-600">Manage your links and track performance</p>
          </div>

          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
                <Plus className="w-4 h-4 mr-2" />
                Create Link
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Link</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div>
                  <Label>Original URL</Label>
                  <Input
                    type="url"
                    placeholder="https://example.com"
                    value={newLink.originalUrl}
                    onChange={(e) => setNewLink({ ...newLink, originalUrl: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label>Title (optional)</Label>
                  <Input
                    placeholder="My awesome link"
                    value={newLink.title}
                    onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Create Link
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="p-6 bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <h3 className="text-sm opacity-90">Total Links</h3>
            <p className="text-3xl font-bold">{links.length}</p>
          </Card>
          <Card className="p-6 bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <h3 className="text-sm opacity-90">Total Clicks</h3>
            <p className="text-3xl font-bold">{links.reduce((sum: number, link: any) => sum + link.clicks, 0)}</p>
          </Card>
          <Card className="p-6 bg-gradient-to-r from-green-500 to-green-600 text-white">
            <h3 className="text-sm opacity-90">Active Links</h3>
            <p className="text-3xl font-bold">{links.filter((link: any) => link.isActive).length}</p>
          </Card>
          <Card className="p-6 bg-gradient-to-r from-orange-500 to-orange-600 text-white">
            <h3 className="text-sm opacity-90">This Month</h3>
            <p className="text-3xl font-bold">0</p>
          </Card>
        </div>

        {/* Links */}
        <Card className="p-6">
          <h2 className="text-xl font-bold mb-6">Your Links</h2>

          {loading ? (
            <div className="text-center py-8">Loading...</div>
          ) : links.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No links yet</p>
              <Button onClick={() => setCreateOpen(true)}>Create your first link</Button>
            </div>
          ) : (
            <div className="space-y-4">
              {links.map((link: any) => (
                <div key={link.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium">{link.title || "Untitled"}</h3>
                      <Badge variant={link.isActive ? "default" : "secondary"}>
                        {link.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 truncate">{link.originalUrl}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                      <span className="flex items-center gap-1">
                        <BarChart3 className="w-3 h-3" />
                        {link.clicks} clicks
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(link.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => copyLink(link.shortCode)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" asChild>
                      <a href={link.originalUrl} target="_blank" rel="noreferrer">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => deleteLink(link.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
