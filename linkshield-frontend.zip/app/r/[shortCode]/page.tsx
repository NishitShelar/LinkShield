"use client"
import { use, useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, ExternalLink, AlertTriangle } from "lucide-react"

export default function RedirectPage({ params }: { params: Promise<{ shortCode: string }> }) {
  const { shortCode } = use(params)
  const [status, setStatus] = useState<"loading" | "found" | "error">("loading")
  const [url, setUrl] = useState("")
  const [countdown, setCountdown] = useState(3)

  useEffect(() => {
    const resolve = async () => {
      try {
        const response = await fetch(`http://localhost:5000/r/${shortCode}`)
        const data = await response.json()

        if (data.success) {
          setUrl(data.data.originalUrl)
          setStatus("found")

          const timer = setInterval(() => {
            setCountdown((prev) => {
              if (prev <= 1) {
                clearInterval(timer)
                window.location.href = data.data.originalUrl
                return 0
              }
              return prev - 1
            })
          }, 1000)
        } else {
          setStatus("error")
        }
      } catch (error) {
        setStatus("error")
      }
    }

    resolve()
  }, [shortCode])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 text-center">
        <div className="mb-6">
          {status === "loading" && <Shield className="w-12 h-12 mx-auto text-blue-600 animate-pulse" />}
          {status === "found" && <Shield className="w-12 h-12 mx-auto text-green-600" />}
          {status === "error" && <AlertTriangle className="w-12 h-12 mx-auto text-red-600" />}
        </div>

        {status === "loading" && (
          <div>
            <h1 className="text-xl font-bold mb-2">Resolving Link...</h1>
            <p className="text-gray-600">Please wait</p>
          </div>
        )}

        {status === "found" && (
          <div>
            <h1 className="text-xl font-bold mb-2">Redirecting...</h1>
            <p className="text-gray-600 mb-4">You'll be redirected in {countdown} seconds</p>
            <div className="p-3 bg-blue-50 rounded-lg mb-4">
              <p className="text-sm text-blue-800 break-all">{url}</p>
            </div>
            <Button onClick={() => (window.location.href = url)} className="w-full">
              <ExternalLink className="w-4 h-4 mr-2" />
              Continue Now
            </Button>
          </div>
        )}

        {status === "error" && (
          <div>
            <h1 className="text-xl font-bold mb-2">Link Not Found</h1>
            <p className="text-gray-600 mb-4">This link doesn't exist or has expired</p>
            <Button onClick={() => (window.location.href = "/")} className="w-full">
              Go Home
            </Button>
          </div>
        )}

        <p className="text-xs text-gray-400 mt-6">Protected by LinkShield</p>
      </Card>
    </div>
  )
}
